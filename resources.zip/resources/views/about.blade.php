@extends('layouts.template')

@section('contenu')

<h2 class="my-4 text-center">A propos de Web Creation</h2>



<div class="header d-flex justify-content-center">
  <p>
    <b>Web Creation</b> est une plateforme de conception d'idées web.
    Nous créons vos idées web.  
  </p>
</div>

@endsection
