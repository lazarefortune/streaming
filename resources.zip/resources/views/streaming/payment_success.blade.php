@extends('layouts.template')

@section('extra-css-streaming')
<style >
.steps-form {
    display: table;
    width: 100%;
    position: relative; }
.steps-form .steps-row {
    display: table-row; }
.steps-form .steps-row:before {
    top: 14px;
    bottom: 0;
    position: absolute;
    content: " ";
    width: 100%;
    height: 1px;
    background-color: #ccc; }
.steps-form .steps-row .steps-step {
    display: table-cell;
    text-align: center;
    position: relative; }
.steps-form .steps-row .steps-step p {
    margin-top: 0.5rem; }
.steps-form .steps-row .steps-step button[disabled] {
    opacity: 1 !important;
    filter: alpha(opacity=100) !important; }
.steps-form .steps-row .steps-step .btn-circle {
    width: 30px;
    height: 30px;
    text-align: center;
    padding: 6px 0;
    font-size: 12px;
    line-height: 1.428571429;
    border-radius: 15px;
    margin-top: 0; }
</style>
@endsection

@section('contenu')

<!-- <div  class="">
  <div class="d-flex justify-content-center">
    <div class="card">

      <div class="alert alert-success" role="alert">
        <h4 class="alert-heading">Envoyé avec succès!</h4>
        <p>Une fois que nôtre équipe aura confirmé votre transfert, vous recevrez vos <b>informations de connexion Netflix</b>. Merci de patientez.</p>
        <hr>
        <p class="mb-0">Consultez régulièrement votre boîte mail, votre messagerie et vos notifications sur notre app.</p>
        <hr>
        <a href="{{ route('streaming.account') }}"  class="btn btn-primary">Cliquez ici</a>
      </div>


    </div>

  </div>

</div> -->



<div class="row d-flex justify-content-center">
  <div class="col-md-8">
    <h2  class="mb-3 text-center"> <i  class="fas fa-cash-register"></i> Caisse</h2>

    <div class="steps-form">
      <div class="steps-row setup-panel">
        <div class="steps-step">
          <a href="#step-9" type="button" class="btn btn-success btn-circle">1</a>
          <p>Paiement</p>
        </div>
        <div class="steps-step">
          <a href="#step-10" type="button" class="btn btn-success btn-circle" disabled="disabled">2</a>
          <p>Preuve du paiement</p>
        </div>
        <div class="steps-step">
          <a href="#step-11" type="button" class="btn btn-success btn-circle" disabled="disabled">3</a>
          <p>Validation</p>
        </div>
      </div>
    </div>



    <div class="card shadow p-3">
      <h4  class="text-center">Vérification du paiement</h4>
      <hr>
      <div class="card-body">
        <form class="" enctype="multipart/form-data" action="{{ route('streaming.payment-proof-store', $stream) }}" method="post">
          @csrf
          <div class="">
            <h5  class="font-weight-bold mb-4">Commande n° {{ $stream->id }}</h5>
          </div>
          <hr>

          <div class="alert alert-success text-dark" role="alert">
            <h4 class="alert-heading">Envoyé avec succès!</h4>
            <p>Notre équipe vérifie votre paiement, vous recevrez vos <b>informations de connexion Netflix</b>. Merci de patientez.</p>
            <hr>
            <p class="mb-0">Consultez régulièrement votre boîte mail, votre messagerie et vos notifications sur notre app.</p>
          </div>


          <hr>
          <div class="">


            <!-- <button type="button" class="btn btn-primary float-right">
              Cliquez ici <i  class="fas fa-arrow-right"></i>
            </button> -->

            <a href="{{ route('streaming.orders') }}"  class="btn btn-primary float-right"> Cliquez ici <i  class="fas fa-arrow-right"></i> </a>


          </div>

        </form>
      </div>
    </div>
  </div>
</div>



@endsection
